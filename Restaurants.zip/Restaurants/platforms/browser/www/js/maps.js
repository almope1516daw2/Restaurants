/*
 * Aplicació que fa us del dibuix de mapes
 * https://developers.google.com/maps/documentation/javascript/
 * phonegap create mapes edu.fje.daw2 mapes
 * cordova platform add android
 * phonegap plugin add org.apache.cordova.geolocation
 * sergi.grau@fje.edu
 * versió 1.0 24.02.2016
 *
 */

var watchID = null;
var tipus= 0, radi=0;
var mapa;


var basedades = {
    createDataBase: function () {
        db = this.obtainBaseDades();
        db.transaction(function (tx) {
            tx.executeSql('CREATE TABLE IF NOT EXISTS RESTAURANTS(nom , lat , long , tipus , radi )');
        });
        this.insertInto()
    },

    obtainBaseDades: function () {
        return window.openDatabase("restBD", "1.0", "Restaurants BD", 200000);
    },

    insertInto: function () {
        db.transaction(function (tx) {
            tx.executeSql('INSERT INTO RESTAURANTS VALUES("Tu","41.434786","2.204175", "0", "0")');
        }, basedades.error);



    }
};

var app = {
    // Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Esdeveniments possibles en la inicialització de l'app:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // callback per a esdeveiniment deviceready
    // this representa l'esdeveniment
    onDeviceReady: function() {
        navigator.geolocation.getCurrentPosition(app.onSuccess, app.onError);
        basedades.createDataBase();
        //watchID =  navigator.geolocation.watchPosition(onSuccess, onError, options);

    },
    //callback per a quan obtenim les dades de l'accelerometre
    onSuccess: function(posicio){
        var latLng  =
            new google.maps.LatLng(
                41.434786,
                2.204175);


        var opcionsMapa = {
            center: latLng,
            panControl: false,
            zoomControl: true,
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        mapa = new google.maps.Map(
            document.getElementById('mapa'),
            opcionsMapa
        );
        var markers = [
            ['Tu',                        41.434786, 2.204175, 0, 0],
            ['Da Greco, Italià',          41.435427, 2.203891, 1, 100],
            ['Palermo, Italià',           41.435154, 2.202721, 1, 100],
            ['La Toscana, Italià',        41.439456, 2.199090, 1, 1000],
            ['Atelier, Frances',          41.440582, 2.198725, 2, 1000],
            ['La Renaissance, Frances',   41.441564, 2.197137, 2, 1000],
            ['Restaurant Paris, Frances', 41.437671, 2.205398, 2, 250],
            ['SushiMax, Japonès',         41.441966, 2.198403, 3, 1000],
            ['Tokyo Eating, Japonès',     41.435414, 2.205677, 3, 100],
            ['Nagoya-Jyo, Japonès',       41.434031, 2.201128, 3, 250],
            ['Euro Döner Kebab, Àrab',    41.434454, 2.205420, 4, 100],
            ['Capital Kebab, Àrab',       41.434164, 2.202888, 4, 100],
            ['Alfarras Döner, Àrab',      41.437542, 2.204797, 4, 250]
        ];
        var infoWindowContent = [
            ['<div class="info_content">' +
            '<h3>Posició actual</h3>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>Da Greco</h3>' +
            '<img src="../img/1_greco.jpg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>Palermo</h3>' +
            '<img src="../img/1_palermo.jpeg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>La Toscana</h3>' +
            '<img src="../img/1_toscana.jpg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>Atelier</h3>' +
            '<img src="../img/2_atelier.jpg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>La Renaissance</h3>' +
            '<img src="../img/2_renaissance.jpg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>Restaurant Paris</h3>' +
            '<img src="../img/2_paris.jpg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>SushiMax</h3>' +
            '<img src="../img/3_sushi.jpg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>Tokyo Eating</h3>' +
            '<img src="../img/3_tokyo.jpg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>Nagoya-Jyo</h3>' +
            '<img src="../img/3_nagoya.jpg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>Euro Döner Kebab</h3>' +
            '<img src="../img/4_euro.jpg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>Capital Kebab</h3>' +
            '<img src="../img/4_capital.jpg" width="150" height="150"/>' +
            '</div>'],
            ['<div class="info_content">' +
            '<h3>Alfarras Döner</h3>' +
            '<img src="../img/4_alfarras.jpeg" width="150" height="150"/>' +
            '</div>']

        ];
        var infoWindow = new google.maps.InfoWindow(), marker, i;
        var iconBase = 'img/marker2.png';
        var iconActual = 'img/marker1.png';
        console.log(tipus);
        var pos= new google.maps.LatLng(markers[0][1], markers[0][2]);
        marker = new google.maps.Marker({
            position: pos,
            map: mapa,
            title: markers[0][0],
            icon: iconActual
        });

        for( i = 0; i < markers.length; i++ ) {
            if((markers[i][3]==tipus && markers[i][4]<=radi) || tipus==0 ){

                var position = new google.maps.LatLng(markers[i][1], markers[i][2]);

                marker = new google.maps.Marker({
                    position: position,
                    map: mapa,
                    title: markers[i][0],
                    icon: iconBase
                });



            google.maps.event.addListener(marker, 'click', (function (marker, i) {
                return function () {

                    infoWindow.setContent(infoWindowContent[i][0]);
                    infoWindow.open(mapa, marker);
                }
            })(marker, i));
            }
        }
        /*var marker = new google.maps.Marker({
            position: latLng,
            map: mapa,
            icon: iconBase});*/




    },

    //callback per a un cas d'error
    onError: function(error){
        var tipusError;

        if(error.code) {
            switch(error.code)
            {
                case 1: // PERMISSION_DENIED
                    tipusError ='manca de permisos';
                    break;
                case 2: // POSITION_UNAVAILABLE
                    tipusError ='posició no disponible.';
                    break;
                case 3: // TIMEOUT
                    tipusError = 'Timeout';
                    break;
                default: // UNKOWN_ERROR
                    tipusError ='Error desconegut';
                    break; }
        }
        var element = document.getElementById('dades');
        element.innerHTML = tipusError;

    }

};
function getType(value){
    tipus=parseInt(value);
    navigator.geolocation.getCurrentPosition(app.onSuccess, app.onError);

}
function getRadius(value){
    radi=parseInt(value);
    navigator.geolocation.getCurrentPosition(app.onSuccess, app.onError);

}
